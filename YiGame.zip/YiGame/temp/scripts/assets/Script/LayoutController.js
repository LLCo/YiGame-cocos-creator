"use strict";
cc._RFpush(module, '3a89e6nkM9BUI1Hh9CKXKEH', 'LayoutController');
// Script\LayoutController.js

cc.Class({
    "extends": cc.Component,

    properties: {},

    // use this for initialization
    onLoad: function onLoad() {
        console.log(this.node.isValid);
    }

});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();