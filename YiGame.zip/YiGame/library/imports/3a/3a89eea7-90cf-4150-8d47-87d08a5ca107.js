cc.Class({
    "extends": cc.Component,

    properties: {},

    // use this for initialization
    onLoad: function onLoad() {
        console.log(this.node.isValid);
    }

});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },